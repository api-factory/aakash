
public class primenumber {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		int a,b=0, flag=0;
				int number=29;
				b=number/2;
				if(number==0||number==1)
					System.out.println(number+"is not a prime");
				else
					{
					for(a=2;a<=b;a++)
						{
						if(number%a==0)
						{
							System.out.println(number+"is not prime");
							flag=1;
							break;
						}
						}
					if(flag==0)
						System.out.println(number+"is prime");
					}
	}
}
