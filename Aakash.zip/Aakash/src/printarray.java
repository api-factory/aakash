
public class printarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={2,5,2,8,5,4};
		for (int element: a)
			System.out.println(element);	
		
	}

}
