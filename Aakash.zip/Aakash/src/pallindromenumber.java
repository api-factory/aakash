
public class pallindromenumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a, sum=0, t,p=97979;


t=p;
while(p>0)
{
	a=p%10;
	sum=(sum*10)+a;
	p=p/10;
}
if(t==sum)    
	   System.out.println("palindrome ");    
	  else    
	   System.out.println("not palindrome");
	}
}



