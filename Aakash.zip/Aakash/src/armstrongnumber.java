
public class armstrongnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int q=0, r, temp;
int number= 407;
temp=number;
while(number>0)
{
r=number%10;
number=number/10;
q=q+(r*r*r);

}
if(temp==q)
	System.out.println("number is armstrong");
else
	System.out.println("not armstrong number");
	
	}

}