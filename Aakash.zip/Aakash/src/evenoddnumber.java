import java.util.Scanner;

public class evenoddnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number;
		System.out.println("enter the no.: ");
		Scanner in= new Scanner(System.in);
		number = in.nextInt();
		
		if(number%2==0)
			System.out.println("number is even");
		else
			System.out.println("number is odd");
		
	}

}