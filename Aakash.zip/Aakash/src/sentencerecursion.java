
public class sentencerecursion {
	
	public String reverseString(String str)
	{
		if(str.isEmpty())
		{
			return str;
			
		}
		else
		{
			return reverseString(str.substring(1))+str.charAt(0);
			
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		sentencerecursion obj = new sentencerecursion();
		String res= obj.reverseString("wipro tech");
		System.out.println(res);
		
		
	}

}
