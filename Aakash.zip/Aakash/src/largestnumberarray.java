import java.util.Scanner;

public class largestnumberarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num, max;
		Scanner s = new Scanner(System.in);
		System.out.println("enter the number of elements in array:");
		num=s.nextInt();
		int a[]= new int[num];
		System.out.println("enter elements of array:");
		for(int i=0;i<num;i++)
		{
			a[i]=s.nextInt();
			
			
		}
		max=a[0];
		for (int i=0; i<num; i++)
		{
			if(max<a[i])
			{
				max=a[i];
				
			}
			
		}
		System.out.println("max value in array is:"+max);
		
	}

}
